# VA-BSIM3v3
Verilog-A implementation of MOSFET model BSIM3v3

# License
CC-BY-NC 4.0
