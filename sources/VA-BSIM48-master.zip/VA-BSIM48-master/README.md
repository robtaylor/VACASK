# VA-BSIM48
Verilog-A implementation of MOSFET model BSIM4.8

# License
CC-BY-NC 4.0
